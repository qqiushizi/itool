/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

// [PATTERN] Block Scheduler 策略定义
// Host 侧通过此文件访问调度策略常量，不需要修改

/*!
 * \file block_scheduler_policy.h
 * \brief Scheduler policy definitions for SWAT quantized matmul kernels.
 */

#ifndef BLOCK_SCHEDULER_POLICY_H
#define BLOCK_SCHEDULER_POLICY_H

#include <cstdint>

// This policy tag is intentionally tiny: it only carries the selected
// execution mode so the scheduler and downstream block pipeline agree on the
// same SWAT path at compile time.
template <uint64_t FULL_LOAD_MODE_>
struct QuantMatmulMxSwatScheduler {
    // `fullLoadMode` is consumed by trait selection only; no runtime state is
    // stored in this tag type.
    static constexpr uint64_t fullLoadMode = FULL_LOAD_MODE_;
};
#endif
