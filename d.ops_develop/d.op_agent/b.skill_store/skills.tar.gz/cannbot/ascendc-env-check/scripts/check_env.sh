#!/bin/bash
# 环境检查脚本
# 用途：检查 Ascend C 算子运行环境是否正确配置

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "================================"
echo "Ascend C 环境检查"
echo "================================"
echo ""

ERRORS=0
WARNINGS=0

CANN_TOOLKIT_PATH=""
_CANN_TOOLKIT_DERIVED=false

_derive_from_opp_path() {
    local opp="${ASCEND_OPP_PATH:-}"
    if [ -n "$opp" ] && [ "${opp##*/opp}" = "$opp" ] && [ "$opp" != "/" ]; then
        local toolkit="${opp%/opp}"
        if [ -d "$toolkit/compiler" ]; then
            echo "$toolkit"
            return
        fi
    fi
    echo ""
}

_resolve_toolkit_path() {
    local base="$1"
    if [ -d "$base/compiler" ]; then
        echo "$base"
        return
    fi
    local toolkit_dir="$base/ascend-toolkit"
    if [ -d "$toolkit_dir" ]; then
        for d in $(ls -d "$toolkit_dir"/* 2>/dev/null | sort -r); do
            if [ -d "$d/compiler" ]; then
                echo "$d"
                return
            fi
        done
        if [ -L "$toolkit_dir/latest" ]; then
            local real
            real=$(readlink -f "$toolkit_dir/latest")
            if [ -d "$real/compiler" ]; then
                echo "$real"
                return
            fi
        fi
    fi
    for d in $(ls -d "$base"/cann-* 2>/dev/null | sort -r); do
        if [ -d "$d/compiler" ]; then
            echo "$d"
            return
        fi
    done
    echo ""
}

_resolve_toolkit_from_env() {
    local derived=$(_derive_from_opp_path)
    if [ -n "$derived" ]; then
        CANN_TOOLKIT_PATH="$derived"
        _CANN_TOOLKIT_DERIVED=true
        return
    fi
    for var in ASCEND_TOOLKIT_HOME ASCEND_HOME; do
        local val="${!var:-}"
        if [ -n "$val" ] && [ -d "$val" ]; then
            local resolved=$(_resolve_toolkit_path "$val")
            if [ -n "$resolved" ]; then
                CANN_TOOLKIT_PATH="$resolved"
                return
            fi
        fi
    done
    if [ -n "$ASCEND_HOME_PATH" ] && [ -d "$ASCEND_HOME_PATH" ]; then
        local resolved=$(_resolve_toolkit_path "$ASCEND_HOME_PATH")
        if [ -n "$resolved" ]; then
            CANN_TOOLKIT_PATH="$resolved"
            return
        fi
    fi
}

_find_set_env_sh() {
    local path="$1"
    for se in \
        "$path/set_env.sh" \
        "$(dirname "$path")/set_env.sh" \
        "$ASCEND_HOME_PATH/ascend-toolkit/set_env.sh" \
        "$ASCEND_HOME_PATH/set_env.sh" \
        "$HOME/Ascend/ascend-toolkit/set_env.sh"; do
        if [ -f "$se" ]; then
            echo "$se"
            return
        fi
    done
    echo ""
}

_resolve_toolkit_from_env

# 1. 检查 CANN Toolkit 环境
echo -e "${YELLOW}[1/7] 检查 CANN Toolkit 环境...${NC}"
if [ -z "$CANN_TOOLKIT_PATH" ]; then
    echo -e "${RED}✗ 无法定位 CANN Toolkit 目录${NC}"
    echo "  官方配置方法："
    echo "    source /usr/local/Ascend/ascend-toolkit/set_env.sh"
    ERRORS=$((ERRORS + 1))
else
    if [ "$_CANN_TOOLKIT_DERIVED" = true ]; then
        echo -e "${GREEN}✓ Toolkit 路径（从 ASCEND_OPP_PATH 推导）= $CANN_TOOLKIT_PATH${NC}"
    else
        echo -e "${GREEN}✓ ASCEND_HOME_PATH = $ASCEND_HOME_PATH${NC}"
        if [ "$ASCEND_HOME_PATH" != "$CANN_TOOLKIT_PATH" ]; then
            echo -e "${GREEN}  → 实际 toolkit: $CANN_TOOLKIT_PATH${NC}"
        fi
    fi

    SET_ENV_SH=$(_find_set_env_sh "$CANN_TOOLKIT_PATH")
    if [ -n "$SET_ENV_SH" ]; then
        echo -e "${GREEN}  ✓ set_env.sh 存在: $SET_ENV_SH${NC}"
    else
        echo -e "${YELLOW}  ⚠ set_env.sh 未找到，环境可能未 source${NC}"
        WARNINGS=$((WARNINGS + 1))
    fi
fi

echo ""

_get_cann_version() {
    declare -g CANN_VERSION=""
    declare -g CANN_RUNTIME_REQ=""
    if [ -n "$CANN_TOOLKIT_PATH" ] && [ -f "$CANN_TOOLKIT_PATH/compiler/version.info" ]; then
        CANN_VERSION=$(grep '^Version=' "$CANN_TOOLKIT_PATH/compiler/version.info" | cut -d'=' -f2)
        CANN_RUNTIME_REQ=$(grep '^required_package_runtime_version=' "$CANN_TOOLKIT_PATH/compiler/version.info" | cut -d'=' -f2 | tr -d '"')
    fi
    if [ -z "$CANN_VERSION" ] && [ -n "$CANN_TOOLKIT_PATH" ]; then
        CANN_VERSION=$(basename "$CANN_TOOLKIT_PATH" | sed 's/cann-//' | sed 's/-beta\./\./')
    fi
}

echo -e "${YELLOW}[2/7] 检查 CANN 版本...${NC}"
_get_cann_version

if [ -z "$CANN_VERSION" ]; then
    echo -e "${YELLOW}⚠ 无法检测 CANN 版本${NC}"
    echo "  建议确认 CANN Toolkit 已正确安装"
    WARNINGS=$((WARNINGS + 1))
else
    echo -e "${GREEN}✓ CANN 版本: $CANN_VERSION${NC}"
    if [ -n "$CANN_RUNTIME_REQ" ]; then
        echo "  依赖运行时基线: $CANN_RUNTIME_REQ（来自 version.info）"
    fi
    echo "  版本配套关系请查阅 CANN 官方 Release Notes：https://www.hiascend.com/cann/document"
fi

echo ""

# 3. 检查 CANN Ops 环境（运行态依赖）
echo -e "${YELLOW}[3/7] 检查 CANN Ops 环境（运行态依赖）...${NC}"
if [ -z "$ASCEND_OPP_PATH" ]; then
    echo -e "${YELLOW}⚠ ASCEND_OPP_PATH 未设置${NC}"
    echo "  说明："
    echo "    - 编译算子时：可以跳过（不影响编译）"
    echo "    - 运行算子时：必需（需安装 CANN Ops 包）"
    echo ""
    echo "  解决方法："
    echo "    1. Docker 环境：镜像已包含 CANN Ops，检查是否 source set_env.sh"
    echo "    2. 手动安装："
    echo "       ./Ascend-cann-\${soc_name}-ops_*.run --install --install-path=\${install_path}"
    echo "       source \${install_path}/cann/set_env.sh"
    WARNINGS=$((WARNINGS + 1))
else
    echo -e "${GREEN}✓ ASCEND_OPP_PATH = $ASCEND_OPP_PATH${NC}"
    
    if [ -d "$ASCEND_OPP_PATH/vendors" ]; then
        vendor_count=$(find "$ASCEND_OPP_PATH/vendors" -maxdepth 1 -type d | tail -n +2 | wc -l)
        echo -e "${GREEN}  ✓ CANN Ops 已安装（$vendor_count 个 vendors）${NC}"
    else
        echo -e "${YELLOW}  ⚠ vendors 目录不存在，CANN Ops 可能未正确安装${NC}"
        WARNINGS=$((WARNINGS + 1))
    fi
fi

echo ""

# 4. 检查自定义算子包（可选）
echo -e "${YELLOW}[4/7] 检查自定义算子包...${NC}"
VENDOR_BASE="${ASCEND_OPP_PATH:-$CANN_TOOLKIT_PATH/opp}"
if [ -z "$CANN_TOOLKIT_PATH" ] && [ -z "$ASCEND_OPP_PATH" ]; then
    echo -e "${YELLOW}⚠ 跳过检查（Toolkit 和 OPP 路径均未设置）${NC}"
else
    VENDOR_DIRS=$(find "$VENDOR_BASE/vendors" -maxdepth 1 -type d 2>/dev/null | tail -n +2 || true)
    
    if [ -n "$VENDOR_DIRS" ]; then
        found_custom=0
        for vendor_dir in $VENDOR_DIRS; do
            vendor_name=$(basename "$vendor_dir")
            op_api_lib=""
            if [ -d "$vendor_dir/op_api/lib" ]; then
                op_api_lib="$vendor_dir/op_api/lib"
            elif [ -d "$vendor_dir/op_impl/ai_core/tbe/op_api/lib" ]; then
                op_api_lib="$vendor_dir/op_impl/ai_core/tbe/op_api/lib"
            fi
            
            if [ -n "$op_api_lib" ] && [ -d "$op_api_lib" ]; then
                so_count=$(find "$op_api_lib" -name "*.so" 2>/dev/null | wc -l)
                echo -e "${GREEN}✓ $vendor_name: $so_count 个算子已安装${NC}"
                
                if ! echo "$LD_LIBRARY_PATH" | grep -q "vendors/${vendor_name}/"; then
                    echo -e "${YELLOW}  ⚠ LD_LIBRARY_PATH 未配置${NC}"
                    echo "    建议：export LD_LIBRARY_PATH=$op_api_lib:\$LD_LIBRARY_PATH"
                    WARNINGS=$((WARNINGS + 1))
                fi
                found_custom=1
            fi
        done
        
        if [ $found_custom -eq 0 ]; then
            echo -e "${YELLOW}⚠ vendors 目录存在但未找到算子库${NC}"
        fi
    else
        echo -e "${YELLOW}⚠ 未安装自定义算子包${NC}"
        echo "  说明：仅运行自定义算子时需要"
    fi
fi

echo ""

# 5. 检查 CANN 工具
echo -e "${YELLOW}[5/7] 检查 CANN 工具...${NC}"
if command -v msprof &> /dev/null; then
    echo -e "${GREEN}✓ msprof 可用${NC}"
else
    echo -e "${YELLOW}⚠ msprof 不可用${NC}"
    WARNINGS=$((WARNINGS + 1))
fi

if command -v cannsim &> /dev/null; then
    echo -e "${GREEN}✓ cannsim 可用${NC}"
else
    echo -e "${YELLOW}⚠ cannsim 不可用（仅 ascend950 需要）${NC}"
fi

echo ""

# 6. 检查日志目录
echo -e "${YELLOW}[6/7] 检查日志目录...${NC}"
LOG_DIR="$HOME/ascend/log/debug/plog"
if [ -d "$LOG_DIR" ]; then
    log_count=$(ls "$LOG_DIR"/*.log 2>/dev/null | wc -l)
    echo -e "${GREEN}✓ 日志目录存在: $log_count 个日志文件${NC}"
else
    echo -e "${YELLOW}⚠ 日志目录不存在: $LOG_DIR${NC}"
    echo "  日志将在首次运行后创建"
fi

echo ""

# 7. 检查环境变量配置
echo -e "${YELLOW}[7/7] 检查调试配置...${NC}"
if [ "$ASCEND_SLOG_PRINT_TO_STDOUT" = "1" ]; then
    echo -e "${GREEN}✓ 日志打屏已开启 (ASCEND_SLOG_PRINT_TO_STDOUT=1)${NC}"
else
    echo -e "${YELLOW}⚠ 日志打屏未开启${NC}"
    echo "  建议：export ASCEND_SLOG_PRINT_TO_STDOUT=1"
fi

echo ""
echo "================================"
echo "检查结果"
echo "================================"
if [ $ERRORS -gt 0 ]; then
    echo -e "${RED}✗ 发现 $ERRORS 个错误${NC}"
    echo "  请先修复错误再运行算子"
    exit 1
elif [ $WARNINGS -gt 0 ]; then
    echo -e "${YELLOW}⚠ 发现 $WARNINGS 个警告${NC}"
    echo "  建议修复警告以提高稳定性"
    exit 0
else
    echo -e "${GREEN}✓ 环境检查通过${NC}"
    exit 0
fi